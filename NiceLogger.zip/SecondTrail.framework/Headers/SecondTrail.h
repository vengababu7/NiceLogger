//
//  SecondTrail.h
//  SecondTrail
//
//  Created by Vengababu Maparthi on 27/12/18.
//  Copyright © 2018 Vengababu Maparthi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SecondTrail.
FOUNDATION_EXPORT double SecondTrailVersionNumber;

//! Project version string for SecondTrail.
FOUNDATION_EXPORT const unsigned char SecondTrailVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SecondTrail/PublicHeader.h>


